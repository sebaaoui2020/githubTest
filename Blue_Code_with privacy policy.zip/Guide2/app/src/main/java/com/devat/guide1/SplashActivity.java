package com.devat.guide1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {

    int loadingTime = 5; // 5 second

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        getData();
    }

    private void checkYourInternet() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.check_title));
        builder.setMessage(getString(R.string.check_internet));
        builder.setCancelable(false);

        builder.setPositiveButton(getString(R.string.try_again), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                getData();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void getData() {
        Volley.newRequestQueue(this).add(new StringRequest(0, Constant.jsonUrl, new Response.Listener<String>() {
            public void onResponse(String str) {
                try {
                    JSONObject jSONObjectRoot = new JSONObject(str);
                    Constant.guideContent = jSONObjectRoot.getJSONArray("GuideContent");
                    JSONObject jsonAds = jSONObjectRoot.getJSONObject("Ads");

                    //----------------------- AdMob -----------------------//
                    JSONObject jsonAdMob = jsonAds.getJSONObject("AdMob");
                    Constant.isAdMob = jsonAdMob.getBoolean("activated");
                    Constant.adMobBannerId = jsonAdMob.getString("banner");
                    Constant.adMobNativeId = jsonAdMob.getString("native");
                    Constant.adMobInterstitialId = jsonAdMob.getString("interstitial");
                    //----------------------- AdMob -----------------------//

                    //----------------------- FAN -----------------------//
                    JSONObject jsonFAN = jsonAds.getJSONObject("FAN");
                    Constant.isFan = jsonFAN.getBoolean("activated");
                    Constant.fanBannerId = jsonFAN.getString("banner");
                    Constant.fanNativeId = jsonFAN.getString("native");
                    Constant.fanInterstitialId = jsonFAN.getString("interstitial");
                    //----------------------- FAN -----------------------//

                    //----------------------- ironSource -----------------------//
                    JSONObject jsonIron = jsonAds.getJSONObject("ironSource");
                    Constant.isIron = jsonIron.getBoolean("activated");
                    Constant.ironAppKey = jsonIron.getString("app_key");
                    //----------------------- ironSource -----------------------//

                    //----------------------- YanDex -----------------------//
                    JSONObject jsonYan = jsonAds.getJSONObject("Yandex");
                    Constant.yanDexInterstitialId = jsonYan.getString("interstitial");
                    //----------------------- YanDex -----------------------//

                    //----------------------- Privacy Policy -----------------------//
                    SharedPreferences prefs = getSharedPreferences("Data", MODE_PRIVATE);
                    JSONObject jsonPrivacy = jSONObjectRoot.getJSONObject("Privacy");
                    Constant.privacyTitle = jsonPrivacy.getString("title");
                    Constant.privacyMessage = jsonPrivacy.getString("message");
                    Constant.privacyUrl = jsonPrivacy.getString("url");
                    Constant.privacyIsEnabled = prefs.getBoolean("privacyIsEnabled", jsonPrivacy.getBoolean("isEnabled"));
                    //----------------------- Privacy Policy -----------------------//

                    //----------------------- Config -----------------------//
                    JSONObject jsonConfig = jSONObjectRoot.getJSONObject("Config");
                    Constant.rattingIsEnabled = jsonConfig.getBoolean("rattingIsEnabled");
                    Constant.package_name = jsonConfig.getString("package_name");
                    Constant.app_version = Float.parseFloat(jsonConfig.getString("app_version"));
                    float appVersion = Float.parseFloat(getAppVersion());
                    if (Constant.app_version > appVersion || !Constant.package_name.equals(getPackageName())) {
                        dialogUpdate(Constant.package_name);
                    } else {
                        startGuide();
                    }
                    //----------------------- Config -----------------------//

                } catch (JSONException e) {
                    checkYourInternet();
                    Log.e("Catch", e.toString());
                }

            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                checkYourInternet();
            }
        }));
    }

    private void startGuide() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait....");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        progressDialog.show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                progressDialog.dismiss();
                startActivity(new Intent(SplashActivity.this, Activity1.class));
                finish();
            }
        }, loadingTime * 1000);
    }

    private String getAppVersion() {
        String result = "";
        try {
            result = getPackageManager()
                    .getPackageInfo(this.getPackageName(), 0)
                    .versionName;
            result = result.replaceAll("[a-zA-Z]|-", "");
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return result;
    }

    private void dialogUpdate(final String pName) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCancelable(false)
                .setTitle(getResources().getString(R.string.update_dialog_title))
                .setMessage(getResources().getString(R.string.update_dialog_message))
                .setPositiveButton(getResources().getString(R.string.update_dialog_btn),
                        (dialog1, which) -> {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pName)));
                            } catch (android.content.ActivityNotFoundException anf) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + pName)));
                            }
                            finish();
                        }).create();
        dialog.show();
    }
}