package com.devat.guide1;

import org.json.JSONArray;
import org.json.JSONObject;

public class Constant {

    public static final String jsonUrl = "https://jsonkeeper.com/b/YEI8";
    public static final int loadingTime = 5 * 1000;

    public static JSONArray guideContent;
    public static String package_name;
    public static float app_version;
    public static boolean rattingIsEnabled;

    public static boolean privacyIsEnabled;
    public static String privacyTitle;
    public static String privacyMessage;
    public static String privacyUrl;

    public static boolean isAdMob;
    public static String adMobBannerId;
    public static String adMobNativeId;
    public static String adMobInterstitialId;

    public static boolean isFan;
    public static String fanBannerId;
    public static String fanNativeId;
    public static String fanInterstitialId;

    public static boolean isIron;
    public static String ironAppKey;

    public static String yanDexInterstitialId;
}
