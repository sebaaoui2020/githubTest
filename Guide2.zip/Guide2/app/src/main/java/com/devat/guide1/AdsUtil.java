package com.devat.guide1;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.ironsource.mediationsdk.ISBannerSize;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.IronSourceBannerLayout;
import com.yandex.mobile.ads.common.InitializationListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AdsUtil {

    Activity context;

    public AdsUtil(Activity activity) {
        this.context = activity;
        initAds();
    }

    public void initAds() {
        if (Constant.isAdMob) {
            MobileAds.initialize(context, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus initializationStatus) {
                }
            });
        } else if (Constant.isFan) {
            AudienceNetworkAds.initialize(context);
        } else if (Constant.isIron) {
            IronSource.setUserId(IronSource.getAdvertiserId(context));
            IronSource.init(context, Constant.ironAppKey);
        } else {
            com.yandex.mobile.ads.common.MobileAds.initialize(context, new InitializationListener() {
                @Override
                public void onInitializationCompleted() {
                }
            });
        }
    }

    private LinearLayout ironBannerLayout;
    private IronSourceBannerLayout banner;

    public void showBanner(LinearLayout bannerLayout) {
        if (Constant.isAdMob) {
            AdView mAdView = new AdView(context);
            mAdView.setAdSize(AdSize.BANNER);
            mAdView.setAdUnitId(Constant.adMobBannerId);
            AdRequest.Builder builder = new AdRequest.Builder();
            mAdView.loadAd(builder.build());
            bannerLayout.addView(mAdView);
        } else if (Constant.isFan) {
            com.facebook.ads.AdView fbAdView = new com.facebook.ads.AdView(context, Constant.fanBannerId, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            bannerLayout.addView(fbAdView);
            fbAdView.loadAd();
        } else if (Constant.isIron) {
            ironBannerLayout = bannerLayout;
            //IronSource.init(context, Constant.ironAppKey, IronSource.AD_UNIT.BANNER);
            banner = IronSource.createBanner(context, ISBannerSize.BANNER);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT);
            ironBannerLayout.addView(banner, 0, layoutParams);
            IronSource.loadBanner(banner);
        }
    }

    public void destroyAndDetachBanner() {
        IronSource.destroyBanner(banner);
        if (ironBannerLayout != null) {
            ironBannerLayout.removeView(banner);
        }
    }

    private InterstitialAd mInterstitialAd;
    private com.facebook.ads.InterstitialAd fbInterstitialAd;
    private com.yandex.mobile.ads.interstitial.InterstitialAd yanInterstitialAd;

    public void loadInterstitial() {
        if (Constant.isAdMob) {
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(context, Constant.adMobInterstitialId, adRequest,
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            mInterstitialAd = interstitialAd;
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            mInterstitialAd = null;
                        }
                    });
        } else if (Constant.isFan) {
            fbInterstitialAd = new com.facebook.ads.InterstitialAd(context, Constant.fanInterstitialId);
            fbInterstitialAd.loadAd();
        } else if (Constant.isIron) {
            //IronSource.init(context, Constant.ironAppKey, IronSource.AD_UNIT.INTERSTITIAL);
            IronSource.loadInterstitial();
        } else {
            yanInterstitialAd = new com.yandex.mobile.ads.interstitial.InterstitialAd(context);
            yanInterstitialAd.setBlockId(Constant.yanDexInterstitialId);
            com.yandex.mobile.ads.common.AdRequest adRequest = new com.yandex.mobile.ads.common.AdRequest.Builder().build();
            yanInterstitialAd.loadAd(adRequest);
        }
    }

    public boolean isLoaded() {
        if (Constant.isAdMob) {
            return mInterstitialAd != null;
        } else if (Constant.isFan) {
            return fbInterstitialAd.isAdLoaded() && fbInterstitialAd != null;
        } else if (Constant.isIron) {
            return IronSource.isInterstitialReady();
        } else {
            return yanInterstitialAd.isLoaded() && yanInterstitialAd != null;
        }
    }

    public void showInterstitial() {
        if (isLoaded()) {
            if (Constant.isAdMob) {
                mInterstitialAd.show(context);
            } else if (Constant.isFan) {
                fbInterstitialAd.show();
            } else if (Constant.isIron) {
                IronSource.showInterstitial();
            } else {
                yanInterstitialAd.show();
            }
        }
    }

    private NativeAd adMobNativeAd;
    private com.facebook.ads.NativeAd nativeAd;

    public void showNative(FrameLayout frameLayout, NativeAdView adView, com.facebook.ads.NativeAdLayout nativeFbLayout, LinearLayout adChoicesContainer, RelativeLayout holderLayout) {
        if (Constant.isAdMob) {
            AdLoader.Builder builder = new AdLoader.Builder(context, Constant.adMobNativeId);
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(NativeAd unifiedNativeAd) {
                    if (adMobNativeAd != null) {
                        adMobNativeAd.destroy();
                    }
                    adMobNativeAd = unifiedNativeAd;
                    populateUnifiedNativeAdView(unifiedNativeAd, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);
                    holderLayout.setVisibility(View.VISIBLE);
                }
            }).build();
            NativeAdOptions adOptions = new NativeAdOptions.Builder().build();
            builder.withNativeAdOptions(adOptions);
            AdLoader adLoader = builder.withAdListener(new AdListener() {
                public void onAdFailedToLoad(int i) {
                    Log.e("Ad Failed To Load", "error code : " + i);
                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else if (Constant.isFan) {
            nativeAd = new com.facebook.ads.NativeAd(context, Constant.fanNativeId);
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {

                }

                @Override
                public void onError(Ad ad, AdError adError) {

                }

                @Override
                public void onAdLoaded(Ad ad) {
                    // Race condition, load() called again before last ad was displayed
                    if (nativeAd == null || nativeAd != ad) {
                        return;
                    }
                    // Inflate Native Ad into Container
                    inflateAd(nativeAd, nativeFbLayout, adChoicesContainer);
                    holderLayout.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdClicked(Ad ad) {

                }

                @Override
                public void onLoggingImpression(Ad ad) {

                }
            };

            nativeAd.loadAd(
                    nativeAd.buildLoadAdConfig()
                            .withAdListener(nativeAdListener)
                            .build());
        }
    }

    private void populateUnifiedNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView(adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));


        ((TextView) Objects.requireNonNull(adView.getHeadlineView())).setText(nativeAd.getHeadline());
        Objects.requireNonNull(adView.getMediaView()).setMediaContent(Objects.requireNonNull(nativeAd.getMediaContent()));


        if (nativeAd.getBody() == null) {
            Objects.requireNonNull(adView.getBodyView()).setVisibility(View.INVISIBLE);

        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            Objects.requireNonNull(adView.getCallToActionView()).setVisibility(View.INVISIBLE);
        } else {
            Objects.requireNonNull(adView.getCallToActionView()).setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getIcon() == null) {
            Objects.requireNonNull(adView.getIconView()).setVisibility(View.GONE);
        } else {
            ((ImageView) Objects.requireNonNull(adView.getIconView())).setImageDrawable(nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            Objects.requireNonNull(adView.getPriceView()).setVisibility(View.INVISIBLE);
        } else {
            Objects.requireNonNull(adView.getPriceView()).setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }
        if (nativeAd.getStore() == null) {
            Objects.requireNonNull(adView.getStoreView()).setVisibility(View.INVISIBLE);
        } else {
            Objects.requireNonNull(adView.getStoreView()).setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            Objects.requireNonNull(adView.getStarRatingView()).setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) Objects.requireNonNull(adView.getStarRatingView())).setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            Objects.requireNonNull(adView.getAdvertiserView()).setVisibility(View.INVISIBLE);
        } else {
            ((TextView) Objects.requireNonNull(adView.getAdvertiserView())).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
    }

    private void inflateAd(com.facebook.ads.NativeAd nativeAd, com.facebook.ads.NativeAdLayout nativeFbLayout, LinearLayout adChoicesContainer) {

        nativeAd.unregisterView();

        LayoutInflater inflater = LayoutInflater.from(context);
        LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.native_fan_layout, nativeFbLayout, false);
        nativeFbLayout.addView(adView);

        AdOptionsView adOptionsView = new AdOptionsView(context, nativeAd, nativeFbLayout);
        try {
            adChoicesContainer.removeAllViews();
            adChoicesContainer.addView(adOptionsView, 0);
        } catch (Exception e) {
            Log.e("Error", e.toString());
        }


        // Create native UI using the ad metadata.
        com.facebook.ads.MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        com.facebook.ads.MediaView nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        // Set the Text.
        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());

        // Create a list of clickable views
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        // Register the Title and CTA button to listen for clicks.
        nativeAd.registerViewForInteraction(
                adView, nativeAdMedia, nativeAdIcon, clickableViews);
    }
}
