package com.devat.guide1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.nativead.NativeAdView;

import org.json.JSONException;

public class MainActivity extends AppCompatActivity {

    AdsUtil adsUtil;
    LinearLayout mBannerAd;
    RelativeLayout holderNative;

    TextView tipTitle, tipDesc ,btnNext;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        position = getIntent().getExtras().getInt("position");

        mBannerAd = findViewById(R.id.adBanner);
        holderNative = findViewById(R.id.nativeHolder);

        adsUtil = new AdsUtil(this);
        adsUtil.showBanner(mBannerAd);
        adsUtil.loadInterstitial();

        FrameLayout frameAdView = findViewById(R.id.adMob_native);
        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.native_adm_layout, null);
        com.facebook.ads.NativeAdLayout nativeFbLayout = findViewById(R.id.fan_native);
        LinearLayout adChoicesContainer = findViewById(R.id.ad_choices_container);
        adsUtil.showNative(frameAdView, adView, nativeFbLayout, adChoicesContainer, holderNative);

        tipTitle = findViewById(R.id.textTitle);
        tipDesc = findViewById(R.id.textDesc);

        try {
            tipTitle.setText(Constant.guideContent.getJSONObject(position).getString("title"));
            tipDesc.setText(Constant.guideContent.getJSONObject(position).getString("description"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (position < Constant.guideContent.length() - 1) {
                    position++;
                } else {
                    position = 0;
                }
                Intent i = new Intent(MainActivity.this, MainActivity.class);
                i.putExtra("position", position);
                startActivity(i);
                finish();
            }
        });
    }
}