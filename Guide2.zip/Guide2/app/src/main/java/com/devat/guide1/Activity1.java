package com.devat.guide1;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Activity1 extends AppCompatActivity {

    AdsUtil adsUtil;
    LinearLayout mBannerAd;
    RelativeLayout holderNative;

    Button btnStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);

        mBannerAd = findViewById(R.id.adBanner);
        holderNative = findViewById(R.id.nativeHolder);

        adsUtil = new AdsUtil(this);
        adsUtil.showBanner(mBannerAd);
        adsUtil.loadInterstitial();

        btnStart = findViewById(R.id.btnStart);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextActivity();
            }
        });

        if (Constant.rattingIsEnabled)
            rateDialog();
    }

    private void nextActivity() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait....");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        progressDialog.show();

        if (Constant.isIron)
            adsUtil.destroyAndDetachBanner();

        Handler handler = new Handler();
        handler.postDelayed(() -> {
            progressDialog.dismiss();
            Intent i = new Intent(Activity1.this, MainActivity.class);
            i.putExtra("position", 0);
            startActivity(i);
            adsUtil.showInterstitial();
        }, Constant.loadingTime);
    }

    private void rateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.rate_dialog_title));
        builder.setMessage(getString(R.string.rate_dialog_message));
        builder.setCancelable(false);

        builder.setPositiveButton(getString(R.string.rate_dialog_yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
                } catch (android.content.ActivityNotFoundException anf) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
                }
            }
        });
        builder.setNegativeButton(getString(R.string.rate_dialog_no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }
}